function salida = magnitud(env)
    salida = sum(abs(env));
end
