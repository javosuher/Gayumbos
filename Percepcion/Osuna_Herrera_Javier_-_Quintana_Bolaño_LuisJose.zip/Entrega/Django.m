if ~exist('imagenes.mat')
	imagenes
end
ReconocedorGUI1
