function salida = energia (env)
    salida = sum(env.^2);
end
